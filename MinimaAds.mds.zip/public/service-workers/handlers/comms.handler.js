// Cross-dapp comms handler — handles MA_* messages via MDS.comms.broadcast.
// Called from service.js onComms(). Rhino-safe syntax.
//
// Protocol (cross-dapp):
//   MA_GET_AD    {userAddress, interests[]}  → MA_AD_RESPONSE {found, ad?}
//   MA_TRACK_VIEW {campaignId, userAddress}  → MA_TRACK_RESULT {confirmed, amount?, reason?}
//
// After a confirmed view, _triggerChannelPayment initiates the payment channel:
//   - No channel: sends CHANNEL_OPEN_REQUEST via Maxima to creator
//   - Channel open: sends REWARD_REQUEST via Maxima to creator

function handleGetAd(payload) {
  var userAddress = payload.userAddress || "";
  var interestsRaw = payload.interests || [];
  var interests = Array.isArray(interestsRaw) ? interestsRaw.join(',') : (interestsRaw || '');

  getCampaigns(function(err, campaigns) {
    if (err || !campaigns || campaigns.length === 0) {
      MDS.comms.broadcast(JSON.stringify({type: "MA_AD_RESPONSE", found: false}), function() {});
      return;
    }
    sqlQuery(
      "SELECT ID, CAMPAIGN_ID, TITLE, BODY, CTA_LABEL, CTA_URL, INTERESTS FROM ADS",
      function(err2, adRows) {
        if (err2) {
          MDS.comms.broadcast(JSON.stringify({type: "MA_AD_RESPONSE", found: false}), function() {});
          return;
        }
        var byCampaign = {};
        var adList = adRows || [];
        for (var i = 0; i < adList.length; i++) {
          var ad = adList[i];
          if (ad.CAMPAIGN_ID) { byCampaign[ad.CAMPAIGN_ID.toUpperCase()] = ad; }
        }
        for (var j = 0; j < campaigns.length; j++) {
          var c = campaigns[j];
          var adData = byCampaign[(c.ID || "").toUpperCase()];
          if (adData) {
            c.AD_ID      = adData.ID;
            c.AD_TITLE   = adData.TITLE;
            c.AD_BODY    = adData.BODY;
            c.AD_CTA_LABEL = adData.CTA_LABEL;
            c.AD_CTA_URL   = adData.CTA_URL;
            c.AD_INTERESTS = adData.INTERESTS;
          }
        }
        var selected = selectAd(userAddress, interests, campaigns);
        if (!selected) {
          MDS.log("[COMMS] MA_GET_AD — no eligible ad for " + userAddress.substring(0, 10) + "...");
          MDS.comms.broadcast(JSON.stringify({type: "MA_AD_RESPONSE", found: false}), function() {});
          return;
        }
        MDS.log("[COMMS] MA_GET_AD → serving campaign:" + selected.ID);
        MDS.comms.broadcast(JSON.stringify({
          type: "MA_AD_RESPONSE",
          found: true,
          ad: {
            campaign_id:  selected.ID,
            title:        selected.AD_TITLE || "",
            body:         selected.AD_BODY || "",
            cta_label:    selected.AD_CTA_LABEL || "",
            cta_url:      selected.AD_CTA_URL || "",
            reward_view:  selected.REWARD_VIEW || 0
          }
        }), function() {});
      }
    );
  });
}

function handleTrackView(payload) {
  var campaignId  = payload.campaignId || "";
  var userAddress = payload.userAddress || "";
  var frameId     = payload.frameId || null;

  if (!campaignId || !userAddress) {
    MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: false, reason: "missing fields"}), function() {});
    return;
  }

  validateView(campaignId, userAddress, function(result) {
    if (!result.valid) {
      MDS.log("[COMMS] MA_TRACK_VIEW rejected: " + result.reason);
      MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: false, reason: result.reason}), function() {});
      return;
    }
    getCampaign(campaignId, function(err, campaign) {
      if (err || !campaign) {
        MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: false, reason: "campaign not found"}), function() {});
        return;
      }
      if (campaign.CREATOR_ADDRESS.toUpperCase() === userAddress.toUpperCase()) {
        MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: false, reason: "creator cannot earn"}), function() {});
        return;
      }
      sqlQuery(
        "SELECT ID FROM ADS WHERE UPPER(CAMPAIGN_ID) = UPPER('" + escapeSql(campaignId) + "')",
        function(err2, rows) {
          var adId   = (rows && rows.length > 0) ? rows[0].ID : "";
          var amount = parseFloat(campaign.REWARD_VIEW) || 0;
          createRewardEvent({
            campaign_id:  campaignId,
            ad_id:        adId,
            user_address: userAddress,
            type:         "view",
            amount:       amount,
            publisher_id: frameId || null
          }, function(err3, evt) {
            if (err3 || !evt) {
              MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: false, reason: "reward event failed"}), function() {});
              return;
            }
            MDS.log("[COMMS] MA_TRACK_VIEW confirmed: campaign=" + campaignId + " amount=" + amount);
            MDS.comms.broadcast(JSON.stringify({type: "MA_TRACK_RESULT", confirmed: true, amount: amount}), function() {});
            _triggerChannelPayment(campaignId, campaign, userAddress, amount, evt.id, frameId);
          });
        }
      );
    });
  });
}

function _triggerChannelPayment(campaignId, campaign, userAddress, amount, eventId, frameId) {
  getChannelState(campaignId, MY_MAXIMA_PK, 'viewer', function(err, channel) {
    if (err || !channel) {
      _sendChannelOpenRequest(campaignId, campaign, userAddress, amount);
    } else if (channel.STATUS === 'open') {
      var cumulative = parseFloat(channel.CUMULATIVE_EARNED) + amount;
      _sendRewardRequest(campaignId, campaign, channel, eventId, cumulative, frameId);
    } else {
      MDS.log("[COMMS] channel " + channel.STATUS + " for campaign: " + campaignId + " — reward pending channel open");
    }
  });
}

function _sendChannelOpenRequest(campaignId, campaign, viewerWalletAddr, amount) {
  if (!MY_MAXIMA_PK || !campaign.CREATOR_ADDRESS) {
    MDS.log("[COMMS] CHANNEL_OPEN_REQUEST skipped — MY_MAXIMA_PK or CREATOR_ADDRESS missing");
    return;
  }
  var maxAmount = parseFloat(campaign.REWARD_VIEW) * 10;
  var payload = {
    type:               "CHANNEL_OPEN_REQUEST",
    campaign_id:        campaignId,
    viewer_key:         MY_MAXIMA_PK,
    viewer_mx:          MY_MX_ADDRESS,
    viewer_wallet_addr: viewerWalletAddr,
    max_amount:         maxAmount,
    role:               "viewer"
  };
  MDS.keypair.get("CREATOR_MX_" + campaignId, function(kpRes) {
    var creatorMx = (kpRes && kpRes.status && kpRes.value) ? kpRes.value : null;
    sendMaxima(campaign.CREATOR_ADDRESS, creatorMx, payload, function(ok) {
      MDS.log("[COMMS] CHANNEL_OPEN_REQUEST sent: campaign=" + campaignId + " max=" + maxAmount + " ok=" + ok);
    });
  });
}

function _sendRewardRequest(campaignId, campaign, channel, eventId, cumulative, frameId) {
  if (!MY_MAXIMA_PK || !campaign.CREATOR_ADDRESS) {
    MDS.log("[COMMS] REWARD_REQUEST skipped — MY_MAXIMA_PK or CREATOR_ADDRESS missing");
    return;
  }
  var payload = {
    type:        "REWARD_REQUEST",
    campaign_id: campaignId,
    viewer_key:  MY_MAXIMA_PK,
    event_id:    eventId,
    cumulative:  cumulative,
    role:        "viewer",
    frame_id:    frameId || ""
  };
  MDS.keypair.get("CREATOR_MX_" + campaignId, function(kpRes) {
    var creatorMx = (kpRes && kpRes.status && kpRes.value) ? kpRes.value : null;
    sendMaxima(campaign.CREATOR_ADDRESS, creatorMx, payload, function(ok) {
      MDS.log("[COMMS] REWARD_REQUEST sent: campaign=" + campaignId + " cumulative=" + cumulative + " ok=" + ok);
    });
  });
}
